Guida rapida iPhone (iOS)

1) Pubblica l'app su un URL HTTPS (obbligatorio per le PWA su iPhone):
   - Opzione veloce: **GitHub Pages** oppure **Vercel/Netlify** (trascina la cartella).
   - Carica l'intero contenuto della cartella (index.html, sw.js, manifest, ecc.).

2) Installa come App su iPhone:
   - Apri l'URL con **Safari**.
   - Tocca il tasto **Condividi** → **Aggiungi alla schermata Home** → **Aggiungi**.

3) Notifiche & promemoria su iPhone:
   - Le notifiche locali funzionano **solo quando l'app è aperta**.
   - Per ricevere avvisi anche a schermo bloccato/chiusa serve il **Web Push** (iOS 16.4+)
     e un piccolo backend. Possiamo aggiungerlo in seguito.

4) Calendario iOS (consigliato per promemoria affidabili):
   - Vai in **Impostazioni** dell'app → **Scarica .ics (prossimi 60 giorni)**.
   - Apri il file su iPhone e scegli **Aggiungi a Calendario**: ti crea gli eventi
     con avvisi integrati del Calendario di iOS.

Suggerimenti:
- Dopo l'installazione come app, aprila almeno una volta al giorno per sincronizzare i promemoria locali.
- In futuro possiamo abilitare sincronizzazione e push tramite backend (es. Vercel + Supabase).