// App logic
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

const state = {
  clienti: [],
  visite: [],
  tasks: [],
  timers: {}
};

function fmtDateTime(dtStr){
  const d = new Date(dtStr);
  if(isNaN(d)) return '';
  return d.toLocaleString();
}
function todayISO(){
  const d = new Date(); d.setHours(0,0,0,0);
  return d.toISOString();
}
function endOfWeek(){
  const d = new Date(); const day = d.getDay(); // 0 sun
  const diff = 6 - (day === 0 ? 6 : day-1); // end Friday? use Sunday end
  d.setDate(d.getDate()+diff); d.setHours(23,59,59,999);
  return d;
}

async function init(){
  await openDB();
  state.clienti = await all('clienti');
  state.visite = await all('visite');
  state.tasks = await all('tasks');
  renderClientiSelects();
  renderClientiTable();
  renderVisiteTable();
  renderTasks();
  renderDashboard();
  initTabs();
  initForms();
  initFilters();
  initCalendar();
  setupNotifications();
}
document.addEventListener('DOMContentLoaded', init);

// Tabs
function initTabs(){
  $$('.tab-btn').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      $$('.tab-btn').forEach(b=>b.classList.remove('active'));
      $$('.tab').forEach(t=>t.classList.remove('active'));
      btn.classList.add('active');
      $('#'+btn.dataset.tab).classList.add('active');
      if(btn.dataset.tab==='calendario') renderCalendarGrid();
    });
  });
}

// Forms
function initForms(){
  // Nuovo cliente dai form
  $('#nuovo-cliente-btn').onclick = ()=> openNewClientPrompt();
  $('#nuovo-cliente2-btn').onclick = ()=> openNewClientPrompt();

  // Visita
  $('#visita-form').addEventListener('submit', async (e)=>{
    e.preventDefault();
    const v = {
      data: $('#visita-data').value || new Date().toISOString(),
      clienteId: parseInt($('#visita-cliente').value || 0),
      note: $('#visita-note').value || '',
      reminder: $('#visita-reminder').checked
    };
    const id = await add('visite', v);
    v.id = id;
    state.visite.push(v);
    if(v.reminder) scheduleReminder('visita', v);
    renderVisiteTable(); renderDashboard(); renderCalendarGrid();
    e.target.reset();
  });

  // Task
  $('#task-form').addEventListener('submit', async (e)=>{
    e.preventDefault();
    const t = {
      titolo: $('#task-titolo').value.trim(),
      clienteId: parseInt($('#task-cliente').value || 0),
      scadenza: $('#task-scadenza').value || null,
      reminder: $('#task-reminder').checked,
      stato: 'aperta', // 'completata'
      createdAt: new Date().toISOString()
    };
    if(!t.titolo) return;
    const id = await add('tasks', t);
    t.id = id;
    state.tasks.push(t);
    if(t.reminder && t.scadenza) scheduleReminder('task', t);
    renderTasks(); renderDashboard(); renderCalendarGrid();
    e.target.reset();
  });

  // Cliente
  $('#cliente-form').addEventListener('submit', async (e)=>{
    e.preventDefault();
    const c = {
      nome: $('#cliente-nome').value.trim(),
      azienda: $('#cliente-azienda').value.trim(),
      contatti: $('#cliente-contatti').value.trim(),
      note: $('#cliente-note').value.trim()
    };
    if(!c.nome) return;
    const id = await add('clienti', c);
    c.id = id;
    state.clienti.push(c);
    renderClientiSelects(); renderClientiTable();
    e.target.reset();
  });

  // Notifiche & import/export
  $('#ask-permission').onclick = requestPermission;
  $('#export-btn').onclick = exportData;
  $('#import-btn').onclick = importData;
}

function openNewClientPrompt(){
  const nome = prompt('Nome cliente');
  if(!nome) return;
  add('clienti', {nome, azienda:'', contatti:'', note:''}).then(id=>{
    state.clienti.push({id, nome, azienda:'', contatti:'', note:''});
    renderClientiSelects(); renderClientiTable();
  });
}

// Clienti
function renderClientiSelects(){
  const opts = ['<option value="">— nessuno —</option>']
    .concat(state.clienti.map(c=>`<option value="${c.id}">${escapeHtml(c.nome)}${c.azienda? ' · '+escapeHtml(c.azienda):''}</option>`)).join('');
  $('#visita-cliente').innerHTML = opts;
  $('#task-cliente').innerHTML = opts;
}
function renderClientiTable(){
  const tbody = $('#clienti-table tbody');
  tbody.innerHTML = '';
  state.clienti.forEach(c=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${escapeHtml(c.nome)}</td>
      <td>${escapeHtml(c.azienda||'')}</td>
      <td>${escapeHtml(c.contatti||'')}</td>
      <td>${escapeHtml(c.note||'')}</td>
      <td class="actionbar">
        <button class="secondary" data-edit="${c.id}">Modifica</button>
        <button class="secondary" data-del="${c.id}">Elimina</button>
      </td>`;
    tbody.appendChild(tr);
  });
  tbody.querySelectorAll('[data-del]').forEach(btn=>{
    btn.onclick = async () => {
      const id = parseInt(btn.dataset.del);
      await del('clienti', id);
      state.clienti = state.clienti.filter(x=>x.id!==id);
      // rimuovi riferimenti da visite/tasks
      state.visite = state.visite.map(v=>v.clienteId===id? {...v, clienteId:0}:v);
      state.tasks = state.tasks.map(t=>t.clienteId===id? {...t, clienteId:0}:t);
      renderClientiTable(); renderClientiSelects(); renderVisiteTable(); renderTasks(); renderCalendarGrid();
    };
  });
  tbody.querySelectorAll('[data-edit]').forEach(btn=>{
    btn.onclick = async () => {
      const id = parseInt(btn.dataset.edit);
      const c = state.clienti.find(x=>x.id===id);
      const nome = prompt('Nome cliente', c.nome); if(nome===null) return;
      const azienda = prompt('Azienda', c.azienda||''); if(azienda===null) return;
      const contatti = prompt('Contatti', c.contatti||''); if(contatti===null) return;
      const note = prompt('Note', c.note||''); if(note===null) return;
      const upd = {...c, nome, azienda, contatti, note};
      await put('clienti', upd);
      Object.assign(c, upd);
      renderClientiTable(); renderClientiSelects(); renderVisiteTable(); renderTasks(); renderCalendarGrid();
    };
  });
}

// Visite
function renderVisiteTable(){
  const tbody = $('#visite-table tbody');
  tbody.innerHTML = '';
  const ordered = [...state.visite].sort((a,b)=> new Date(b.data)-new Date(a.data));
  ordered.forEach(v=>{
    const tr = document.createElement('tr');
    const cliente = state.clienti.find(c=>c.id===v.clienteId);
    tr.innerHTML = `
      <td>${fmtDateTime(v.data)}</td>
      <td>${cliente? escapeHtml(cliente.nome) : '—'}</td>
      <td>${escapeHtml(v.note||'')}</td>
      <td class="actionbar">
        <button class="secondary" data-delv="${v.id}">Elimina</button>
      </td>`;
    tbody.appendChild(tr);
  });
  tbody.querySelectorAll('[data-delv]').forEach(btn=>{
    btn.onclick = async () => {
      const id = parseInt(btn.dataset.delv);
      await del('visite', id);
      state.visite = state.visite.filter(x=>x.id!==id);
      renderVisiteTable(); renderDashboard(); renderCalendarGrid();
    };
  });
}

// Tasks
function initFilters(){
  $$('#attivita .chip').forEach(ch=>{
    ch.addEventListener('click', ()=>{
      $$('#attivita .chip').forEach(x=>x.classList.remove('active'));
      ch.classList.add('active');
      renderTasks();
    });
  });
}
function currentFilter(){
  return $('#attivita .chip.active')?.dataset.filter || 'tutte';
}
function renderTasks(){
  const list = $('#task-list'); list.innerHTML = '';
  const now = new Date();
  let tasks = [...state.tasks].sort((a,b)=> (a.stato==='aperta')? -1:1);
  const filter = currentFilter();
  tasks = tasks.filter(t=>{
    if(filter==='aperte') return t.stato==='aperta';
    if(filter==='completate') return t.stato==='completata';
    if(filter==='scadute') return t.stato==='aperta' && t.scadenza && new Date(t.scadenza) < now;
    return true;
  });
  tasks.forEach(t=>{
    const li = document.createElement('li');
    const cliente = state.clienti.find(c=>c.id===t.clienteId);
    const badges = [];
    if(t.scadenza){
      const overdue = new Date(t.scadenza) < now && t.stato==='aperta';
      badges.push(`<span class="badge ${overdue?'scaduto':''}">${fmtDateTime(t.scadenza)}</span>`);
    }
    if(t.stato==='completata') badges.push('<span class="badge completato">Completata</span>');
    if(cliente) badges.push(`<span class="badge">${escapeHtml(cliente.nome)}</span>`);
    li.innerHTML = `
      <div>
        <div><strong>${escapeHtml(t.titolo)}</strong></div>
        <div class="small">${badges.join(' ')}</div>
      </div>
      <div class="actionbar">
        <button class="secondary" data-done="${t.id}">${t.stato==='aperta'?'✓ Completa':'↺ Riapri'}</button>
        <button class="secondary" data-del="${t.id}">Elimina</button>
      </div>
    `;
    list.appendChild(li);
  });
  list.querySelectorAll('[data-del]').forEach(btn=>{
    btn.onclick = async ()=>{
      const id = parseInt(btn.dataset.del);
      await del('tasks', id);
      state.tasks = state.tasks.filter(x=>x.id!==id);
      renderTasks(); renderDashboard(); renderCalendarGrid();
    };
  });
  list.querySelectorAll('[data-done]').forEach(btn=>{
    btn.onclick = async ()=>{
      const id = parseInt(btn.dataset.done);
      const t = state.tasks.find(x=>x.id===id);
      t.stato = t.stato==='aperta'?'completata':'aperta';
      await put('tasks', t);
      renderTasks(); renderDashboard(); renderCalendarGrid();
    };
  });
}

// Dashboard
function renderDashboard(){
  const oggi = $('#oggi-list'); const set = $('#settimana-list'); const prom = $('#promemoria-list');
  oggi.innerHTML=''; set.innerHTML=''; prom.innerHTML='';
  const start = new Date(); start.setHours(0,0,0,0);
  const end = new Date(); end.setHours(23,59,59,999);
  const weekEnd = endOfWeek();
  const events = [];
  state.visite.forEach(v=>{
    const d = new Date(v.data);
    const entry = {tipo:'Visita', when:d, testo: (state.clienti.find(c=>c.id===v.clienteId)?.nome||'—') + (v.note? ' – '+v.note : '')};
    if(d>=start && d<=end) oggi.appendChild(liEvent(entry));
    if(d> end && d<=weekEnd) set.appendChild(liEvent(entry));
    if(v.reminder) prom.appendChild(liEvent(entry));
  });
  state.tasks.forEach(t=>{
    if(!t.scadenza) return;
    const d = new Date(t.scadenza);
    const entry = {tipo:'Task', when:d, testo: t.titolo};
    if(d>=start && d<=end) oggi.appendChild(liEvent(entry));
    if(d> end && d<=weekEnd) set.appendChild(liEvent(entry));
    if(t.reminder) prom.appendChild(liEvent(entry));
  });
}
function liEvent(e){
  const li = document.createElement('li');
  li.textContent = `${e.tipo}: ${e.testo} (${e.when.toLocaleString()})`;
  return li;
}

// Calendar
let calMonth = new Date();
function initCalendar(){
  calMonth.setDate(1);
  $('#prev-month').onclick = ()=>{ calMonth.setMonth(calMonth.getMonth()-1); renderCalendarGrid(); };
  $('#next-month').onclick = ()=>{ calMonth.setMonth(calMonth.getMonth()+1); renderCalendarGrid(); };
  renderCalendarGrid();
}
function renderCalendarGrid(){
  const label = $('#month-label');
  label.textContent = calMonth.toLocaleString(undefined, { month:'long', year:'numeric' });
  const grid = $('#calendar-grid'); grid.innerHTML = '';
  const firstDay = new Date(calMonth.getFullYear(), calMonth.getMonth(), 1);
  const start = new Date(firstDay); start.setDate(firstDay.getDate() - ((firstDay.getDay()+6)%7)); // Monday grid
  for(let i=0;i<42;i++){
    const day = new Date(start); day.setDate(start.getDate()+i);
    const cell = document.createElement('div'); cell.className='cell';
    const dateDiv = document.createElement('div'); dateDiv.className='date'; dateDiv.textContent = day.getDate();
    cell.appendChild(dateDiv);
    // dots
    const dots = document.createElement('div'); dots.style.position='absolute'; dots.style.bottom='6px'; dots.style.left='6px'; dots.style.display='flex'; dots.style.gap='6px';
    const hasVisita = state.visite.some(v=> sameDay(new Date(v.data), day));
    const hasTask = state.tasks.some(t=> t.scadenza && sameDay(new Date(t.scadenza), day));
    if(hasVisita){ const d=document.createElement('span'); d.className='dot visita'; dots.appendChild(d); }
    if(hasTask){ const d=document.createElement('span'); d.className='dot task'; dots.appendChild(d); }
    cell.appendChild(dots);
    // style outside month
    if(day.getMonth() !== calMonth.getMonth()) cell.style.opacity = 0.4;
    grid.appendChild(cell);
  }
}
function sameDay(a,b){
  return a.getFullYear()===b.getFullYear() && a.getMonth()===b.getMonth() && a.getDate()===b.getDate();
}

// Notifications
function setupNotifications(){
  // schedule existing
  state.visite.filter(v=>v.reminder).forEach(v=> scheduleReminder('visita', v));
  state.tasks.filter(t=>t.reminder && t.scadenza).forEach(t=> scheduleReminder('task', t));
}
function requestPermission(){
  if(!('Notification' in window)) return alert('Notifiche non supportate nel browser.');
  Notification.requestPermission().then(res=>{
    alert(res==='granted' ? 'Notifiche abilitate ✅' : 'Notifiche non abilitate');
  });
}
function scheduleReminder(type, item){
  if(!('Notification' in window)) return;
  if(Notification.permission!=='granted') return;
  // clear previous
  const key = type+'-'+item.id;
  if(state.timers[key]) clearTimeout(state.timers[key]);
  let when = new Date();
  if(type==='visita'){
    when = new Date(item.data); when = new Date(when.getTime() - 30*60*1000); // 30 min before
  }else{
    when = new Date(item.scadenza);
  }
  const delay = when.getTime() - Date.now();
  if(delay <= 0) return; // in passato
  state.timers[key] = setTimeout(()=>{
    new Notification(type==='visita' ? 'Promemoria visita' : 'Promemoria attività', {
      body: type==='visita'
        ? (clientName(item.clienteId) + (item.note? ' – '+item.note:''))
        : item.titolo,
      tag: key
    });
    delete state.timers[key];
  }, Math.min(delay, 2147483647)); // max setTimeout ~24 giorni
}
function clientName(id){
  return state.clienti.find(c=>c.id===id)?.nome || 'Cliente';
}

// Import/export
function exportData(){
  const data = {
    clienti: state.clienti,
    visite: state.visite,
    tasks: state.tasks
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'agente-dati.json'; a.click();
  URL.revokeObjectURL(url);
}
function importData(){
  const file = $('#import-file').files[0];
  if(!file) return alert('Seleziona un file JSON.');
  const reader = new FileReader();
  reader.onload = async (e)=>{
    try{
      const data = JSON.parse(e.target.result);
      // rudimentary merge: wipe and insert
      const dbReq = indexedDB.deleteDatabase('agenteDB');
      dbReq.onsuccess = async ()=>{
        await openDB();
        for(const c of (data.clienti||[])) await add('clienti', {...c, id: undefined});
        for(const v of (data.visite||[])) await add('visite', {...v, id: undefined});
        for(const t of (data.tasks||[])) await add('tasks', {...t, id: undefined});
        state.clienti = await all('clienti');
        state.visite = await all('visite');
        state.tasks = await all('tasks');
        renderClientiSelects(); renderClientiTable(); renderVisiteTable(); renderTasks(); renderDashboard(); renderCalendarGrid();
        alert('Import completato ✅');
      };
      dbReq.onerror = ()=> alert('Errore durante l'import.');
    }catch(err){ alert('File non valido.'); }
  };
  reader.readAsText(file);
}

// Utils
function escapeHtml(str){
  return (str||'').replace(/[&<>"']/g, m=> ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}


// --- iOS Calendar (.ics) Export ---
function exportICS(){
  // build events from visits with reminder and tasks with due date within next 60 days
  const now = new Date();
  const until = new Date(now.getTime() + 60*24*60*60*1000);
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Agente PWA//IT',
    'CALSCALE:GREGORIAN'
  ];
  function fmtICSDate(d){ // UTC in floating time to let iOS adjust
    const pad = (n)=> String(n).padStart(2,'0');
    return d.getUTCFullYear()+pad(d.getUTCMonth()+1)+pad(d.getUTCDate())+'T'+pad(d.getUTCHours())+pad(d.getUTCMinutes())+pad(d.getUTCSeconds())+'Z';
  }
  const uidBase = Date.now() + '-' + Math.random().toString(36).slice(2);
  let uidCounter = 0;

  // Visits -> 1h meeting
  state.visite.forEach(v=>{
    const start = new Date(v.data);
    if(start<now || start>until) return;
    const end = new Date(start.getTime()+60*60*1000);
    const cliente = clientName(v.clienteId);
    const title = 'Visita: ' + cliente;
    const desc = (v.note||'') + (v.reminder? '\nPromemoria 30 min prima (in-app)' : '');
    lines.push('BEGIN:VEVENT');
    lines.push('UID:'+uidBase+'-'+(++uidCounter)+'@agente-pwa');
    lines.push('DTSTAMP:'+fmtICSDate(new Date()));
    lines.push('DTSTART:'+fmtICSDate(start));
    lines.push('DTEND:'+fmtICSDate(end));
    lines.push('SUMMARY:'+title.replace(/[\n\r]/g,' '));
    lines.push('DESCRIPTION:'+desc.replace(/[\n\r]/g,' '));
    // add default 30-min alert
    lines.push('BEGIN:VALARM');
    lines.push('TRIGGER:-PT30M');
    lines.push('ACTION:DISPLAY');
    lines.push('DESCRIPTION:Promemoria visita');
    lines.push('END:VALARM');
    lines.push('END:VEVENT');
  });
  // Tasks -> dated tasks as 30-min events
  state.tasks.forEach(t=>{
    if(!t.scadenza) return;
    const start = new Date(t.scadenza);
    if(start<now || start>until) return;
    const end = new Date(start.getTime()+30*60*1000);
    const cliente = clientName(t.clienteId);
    const title = 'Task: ' + t.titolo + (cliente? ' · '+cliente:'');
    const desc = 'Stato: '+t.stato;
    lines.push('BEGIN:VEVENT');
    lines.push('UID:'+uidBase+'-'+(++uidCounter)+'@agente-pwa');
    lines.push('DTSTAMP:'+fmtICSDate(new Date()));
    lines.push('DTSTART:'+fmtICSDate(start));
    lines.push('DTEND:'+fmtICSDate(end));
    lines.push('SUMMARY:'+title.replace(/[\n\r]/g,' '));
    lines.push('DESCRIPTION:'+desc.replace(/[\n\r]/g,' '));
    if(t.reminder){
      lines.push('BEGIN:VALARM');
      lines.push('TRIGGER:-PT0M');
      lines.push('ACTION:DISPLAY');
      lines.push('DESCRIPTION:Promemoria task');
      lines.push('END:VALARM');
    }
    lines.push('END:VEVENT');
  });

  lines.push('END:VCALENDAR');
  const blob = new Blob([lines.join('\r\n')], {type:'text/calendar'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'Agente-Calendario.ics'; a.click();
  URL.revokeObjectURL(url);
}

document.addEventListener('DOMContentLoaded', ()=>{
  const btn = document.getElementById('export-ics-btn');
  if(btn) btn.addEventListener('click', exportICS);
});
