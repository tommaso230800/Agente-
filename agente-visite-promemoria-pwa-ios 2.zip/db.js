// IndexedDB helper
const DB_NAME = 'agenteDB';
const DB_VERSION = 1;
let db;

function openDB(){
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if(!db.objectStoreNames.contains('clienti')){
        const s = db.createObjectStore('clienti', { keyPath: 'id', autoIncrement: true });
        s.createIndex('nome', 'nome', { unique: false });
      }
      if(!db.objectStoreNames.contains('visite')){
        const s = db.createObjectStore('visite', { keyPath: 'id', autoIncrement: true });
        s.createIndex('data', 'data', { unique: false });
      }
      if(!db.objectStoreNames.contains('tasks')){
        const s = db.createObjectStore('tasks', { keyPath: 'id', autoIncrement: true });
        s.createIndex('scadenza', 'scadenza', { unique: false });
        s.createIndex('stato', 'stato', { unique: false });
      }
    };
    req.onsuccess = () => { db = req.result; resolve(db); };
    req.onerror = () => reject(req.error);
  });
}

function tx(store, mode='readonly'){
  return db.transaction(store, mode).objectStore(store);
}

function add(store, val){
  return new Promise((res, rej) => {
    const req = tx(store, 'readwrite').add(val);
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}
function put(store, val){
  return new Promise((res, rej) => {
    const req = tx(store, 'readwrite').put(val);
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}
function del(store, key){
  return new Promise((res, rej) => {
    const req = tx(store, 'readwrite').delete(key);
    req.onsuccess = () => res();
    req.onerror = () => rej(req.error);
  });
}
function all(store, index=null){
  return new Promise((res, rej) => {
    const s = tx(store);
    const arr = [];
    const src = index ? s.index(index).openCursor() : s.openCursor();
    src.onsuccess = (e) => {
      const cur = e.target.result;
      if(cur){ arr.push(cur.value); cur.continue(); }
      else res(arr);
    };
    src.onerror = () => rej(src.error);
  });
}
