# Agente – Visite & Promemoria (PWA)
App web offline‑ready per agenti di commercio per registrare visite, attività/to‑do, clienti/aziende e visualizzare tutto su calendario con promemoria locali.

## Come usare
1. Scarica e apri `index.html` in un browser moderno (Chrome, Edge, Safari, Firefox).
2. Con il menu in alto naviga tra Dashboard, Visite, Attività, Clienti/Aziende e Calendario.
3. Abilita le notifiche in **Impostazioni** se vuoi promemoria locali (l'app deve essere aperta per riceverli).
4. Installa come **App** (Aggiungi alla schermata Home) per un'esperienza tipo app (PWA).
5. I dati sono salvati nel tuo browser (IndexedDB). Puoi **esportare** e **importare** i dati da Impostazioni.

## Limiti noti
- Le notifiche locali funzionano solo quando l'app è aperta. Per promemoria garantiti anche a browser chiuso serve un backend (es. invio email/Push con un piccolo server) o integrare con Google Calendar.
- Questo è un MVP. In futuro puoi aggiungere: report PDF, mappe delle visite, pipeline opportunità, sincronizzazione tra dispositivi, utenti multipli.
